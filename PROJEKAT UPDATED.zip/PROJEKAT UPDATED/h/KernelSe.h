

#ifndef KERNELSE_H_
#define KERNELSE_H_

#include "Semaphor.h"
#include "WList.h"
//#include "SemList.h"

class SemList;

extern volatile SemList* allSemaphores ;



class KernelSem {
public:

	int value;
    int numOfBlockedThreads;
	WList* blockedThreads;

	KernelSem(int init);
	virtual ~KernelSem();
	virtual int wait (Time maxTimeToWait);
    virtual int signal(int n);
	int val () const;
	int deblock(int n);


};
void check();
#endif 
