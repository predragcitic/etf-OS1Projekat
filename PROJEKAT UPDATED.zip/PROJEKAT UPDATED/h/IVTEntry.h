

#ifndef IVTENTRY_H_
#define IVTENTRY_H_
#include "event.h"

typedef void interrupt (*pInterrupt)(...);

#define PREPAREENTRY(intNo, old) \
void interrupt newintr##intNo(...); \
IVTEntry newivte##intNo(intNo, newintr##intNo); \
void interrupt newintr##intNo(...) { \
	newivte##intNo.signal(); \
	if (old) { \
		newivte##intNo.callOld(); \
	} \
}


typedef unsigned char IVTNo;
class KernelEv;

class IVTEntry{
public:
	KernelEv* myEvent;
    pInterrupt oldInt;
	IVTNo ivtNumber;

	IVTEntry(IVTNo ivtnum, pInterrupt prekid);
	virtual ~IVTEntry();

	void callOld();
	void signal();

    static IVTEntry* entries[256];
};


#endif 
