

#ifndef THREAD_H_
#define THREAD_H_

#define lock
#ifndef BCC_BLOCK_IGNORE
asm { pushf
			cli;
		}
#endif
#define unlock
#ifndef BCC_BLOCK_IGNORE
asm popf
#endif

typedef unsigned long StackSize;
const StackSize defaultStackSize = 4096;
const StackSize maxStackSize = 65536;
typedef unsigned int Time; // time, x 55ms
const Time defaultTimeSlice = 3; // default = 2*55ms
typedef int ID;

class PCB;       // Kernel's implementation of a user's thread
class List;

//extern volatile PCB* running;

extern volatile unsigned lockFlag;
extern volatile int contextOnDemand ;
extern void interrupt timer();
extern volatile List* pcbList;


class Thread {
public:
	void start();
	void waitToComplete();
	virtual ~Thread();

	ID getId();
    static ID getRunningId();
    static Thread * getThreadById(ID id);
    PCB* myPCB;

protected:
	friend class PCB;
	friend class List;
	Thread(StackSize stackSize = defaultStackSize, Time timeSlice = defaultTimeSlice);
	virtual void run() {}

//private:
	//PCB* myPCB;
};

void dispatch();


#endif 
