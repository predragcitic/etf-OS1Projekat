
 

#ifndef SEMLIST_H_
#define SEMLIST_H_

#include "KernelSe.h"

class SemList {
public:

	struct node{
		KernelSem* data;
		node* next;
	};
	node* head;
	node* tail;
	node* curr;
	node* temp;

	SemList();
	virtual ~SemList();
	void addNode(KernelSem* newKer);
	void deleteNode(KernelSem* delKer);


};


#endif 