

#ifndef IDLE_H_
#define IDLE_H_

#include "Thread.h"


class Idle:Thread{

public:
	Idle();
    void run();
    PCB* getMyPCB(){
    	return myPCB;
    }

};




#endif 
