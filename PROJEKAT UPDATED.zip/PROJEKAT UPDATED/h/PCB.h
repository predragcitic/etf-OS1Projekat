
#ifndef PCB_H_
#define PCB_H_
#include "Thread.h"
#include <dos.h>


static ID posID  = 0;
class List;

class PCB {
public:

  static PCB* running ;


  ID id;

  unsigned* stack;
  unsigned ss;
  unsigned sp;
  unsigned bp;
  Time timeSlice;



  unsigned timeSliceZero;

  unsigned finished;
  unsigned blocked;
  unsigned ready;
  unsigned started;
  unsigned idle;

  unsigned wasWaiting;

  Thread* myThread;

  List* pcbWaiting;

  StackSize size;

	PCB(StackSize sz , Time time, Thread* thr);
	virtual ~PCB();

	static void wrapper();

	friend class Thread;
    friend class List;
};




#endif 
