//pretpostavljeni memorijski model: huge
#ifndef GLOBAL_H_
#define GLOBAL_H_

#include <iostream.h>
#include <dos.h>           // ona sadrzi podrsku za asemblerske makroe(prevezivanje prekidnih rutina...)  setVACT getVACT - na kom ulazu hocu da postavim koju adresu, i moze da se ne kopira nego da napravim svoju
#include "SCHEDULE.H"
#include "PCB.h"
#include "Idle.h"
#include "List.h"
#include "SemList.h"

volatile List* pcbList = new List();      // !!!!!!!!!!! vidi moze li ovo da prodje!!
volatile SemList* allSemaphores = new SemList();

volatile unsigned lockFlag = 1;             //volatile jer moze menjati vise niti
unsigned tsp;
unsigned tss;
unsigned tbp;
//volatile PCB* running;
volatile PCB* idlePCB ;
volatile PCB* mainPCB;

volatile unsigned counter = 20;
volatile int contextOnDemand  = 0;
unsigned oldTimerOFF, oldTimerSEG;

void init();
void interrupt timer();
void restore();






#endif
