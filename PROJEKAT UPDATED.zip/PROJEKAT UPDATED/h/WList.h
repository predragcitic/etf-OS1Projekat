
#ifndef WLIST_H_
#define WLIST_H_

#include "PCB.h"

class WList {
public:



	struct node{
		PCB* data;
        Time timeslice;
		node* next;

	};
	node* head;
	node* tail;
	node* curr;
	node* temp;

	WList();
	void addNode(PCB* newPCB, Time max = 0);

	//void wakeUp();
	void deleteNode(PCB* delPCB);
	PCB* takeFirst();
	virtual ~WList();
};

#endif 
