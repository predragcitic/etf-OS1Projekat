



#ifndef LIST_H_
#define LIST_H_



#include "PCB.h"
#include "Thread.h"





class List{
public:
	struct node{
		PCB* data;
		node* next;

	};
	node* head;
	node* tail;
	node* curr;
	node* temp;

	List();
	virtual ~List();
	void addNode(PCB* newPCB);
	Thread* findThreadByID(ID id);
	void wakeUp();
	void deleteNode(PCB* delPCB);

};


#endif 
