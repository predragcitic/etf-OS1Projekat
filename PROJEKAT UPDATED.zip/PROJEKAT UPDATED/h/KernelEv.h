

#ifndef KERNELEV_H_
#define KERNELEV_H_


#include "IVTEntry.h"
#include "SCHEDULE.h"
typedef unsigned char IVTNo;
class PCB;

class KernelEv{
public:
	KernelEv(IVTNo ivtnum);
	~KernelEv();

	void signal();
	void wait();

	PCB * myOwner;
	int value;
	IVTNo ivtNum;

};




#endif 
