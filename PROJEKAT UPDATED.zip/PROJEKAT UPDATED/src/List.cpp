




#include "List.h"
#include "SCHEDULE.H"

List::List(){
	head = 0;
	curr = 0;
	temp = 0;
	tail = 0;
}
List::~List(){
curr = head;
if (!curr){
	temp = tail = 0;
	//delete temp; //   OVO SI MENJAO U LISTAMA!!!!
}
else while(curr){
	temp = curr;
	curr = curr->next;
	delete temp;
}
 //delete tail; delete head;

}

void List::addNode(PCB* newPCB){
	node* n = new node;
	n->next = 0;
	n->data = newPCB;

	if(head) {
		tail->next = n;
		tail = n;
	}
	else {
		head = tail = n;
	}

}

Thread* List::findThreadByID(ID id){
	curr = head;
	while(curr && curr->data->id!=id) curr = curr->next;
	if (!curr) return 0;
	return curr->data->myThread;
}


void List:: wakeUp(){


	while(head!=0){
		curr = head;

		head->data->blocked = 0;
		head->data->ready = 1;
		Scheduler::put(head->data);
		head = head->next;
		delete curr;

	}
	tail = 0; temp = 0;
}

void List::deleteNode(PCB* delPCB){       //obezbedi sve sto treba za brisanje liste
    temp = 0;
	curr = head;
	while(curr && curr->data!=delPCB){
		temp = curr;
		curr = curr->next;
	}
	if (!curr) return;

	if(curr == head) {head = head->next; delete curr;  if (head == 0) {tail = 0;}}
	else if(curr == tail) {tail = temp; delete curr; tail->next = 0;}
	else {temp -> next = curr -> next; delete curr;}


}
