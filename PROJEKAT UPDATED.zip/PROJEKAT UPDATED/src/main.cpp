
#include <DOS.H>
#include <STDIO.H>
#include <STDARG.H>
#include <stdio.h>
#include <iostream.h>
#include <dos.h>
//#include "Global.h"
#include "Thread.h"
#include "PCB.h"
#include "SCHEDULE.H"
#include "List.h"
#include "Semaphor.h"
#include "Event.h"

#include "bounded.h"
#include "intLock.h"
#include "keyevent.h"
#include "user.h"

#include <stdlib.h>

extern int userMain (int argc, char* argv[]);

extern void init();
extern void restore();




int main(int argc, char* argv[]){
//cout<<"krenuo"<<endl;

	init();

	int returnValue;
//cout<<"op"<<endl;
	returnValue = userMain(argc,argv);

	restore();
	return returnValue;
}


