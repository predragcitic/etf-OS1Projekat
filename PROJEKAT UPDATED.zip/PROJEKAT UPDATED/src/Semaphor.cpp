

#include "Semaphor.h"
#include "KernelSe.h"

Semaphore::Semaphore(int init) {
	lockFlag = 0;
myImpl = new KernelSem(init);
    lockFlag = 1;

}

Semaphore::~Semaphore() {
 lockFlag = 0;
 delete myImpl;
 lockFlag = 1;
// myImpl = 0;
}

int Semaphore:: wait (Time maxTimeToWait){
 return myImpl->wait(maxTimeToWait);
}
int Semaphore:: signal(int n){
return myImpl->signal(n);
}

int Semaphore::val () const{
	return myImpl->val();
}
