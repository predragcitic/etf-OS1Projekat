

#include "Global.h"
#include "Thread.h"
#include "Idle.h"
#include <iostream.h>
#include <stdio.h>
#include <dos.h>


class Idle;
class Thread;

extern void tick();
extern void check();


void init(){

#ifndef BCC_BLOCK_IGNORE
	asm{
		cli
		push es
		push ax

		mov ax,0   //  ; inicijalizuje rutinu za tajmer
		mov es,ax

		mov ax, word ptr es:0022h //; pamti staru rutinu
		mov word ptr oldTimerSEG, ax
		mov ax, word ptr es:0020h
		mov word ptr oldTimerOFF, ax

		mov word ptr es:0022h, seg timer	 //postavlja
		mov word ptr es:0020h, offset timer //novu rutinu

		mov ax, oldTimerSEG	 //	postavlja staru rutinu
		mov word ptr es:0182h, ax //; na int 60h
		mov ax, oldTimerOFF
		mov word ptr es:0180h, ax

		pop ax
		pop es
		sti
	}
#endif

	mainPCB = new PCB(defaultStackSize, 7, 0);


				PCB::running = (PCB*)mainPCB;
				PCB::running -> ready = 1;
				counter = PCB::running->timeSlice;

				//Scheduler::put((PCB*)main);

				Idle* idleThread = new Idle();



}






void interrupt timer(){

	if(!contextOnDemand) {
		tick();
	#ifndef BCC_BLOCK_IGNORE
		asm int 60h;
	#endif
	}
	if (!contextOnDemand && !PCB::running->timeSliceZero){
		counter--;
		check();

	}

	if ((counter == 0 && !PCB::running->timeSliceZero) || contextOnDemand) {
		if (lockFlag == 1){
	        contextOnDemand = 0;
#ifndef BCC_BLOCK_IGNORE
		asm {
			// cuva sp
			mov tsp, sp
			mov tss, ss
			mov tbp, bp
		}
#endif
		    PCB::running->sp = tsp;
		    PCB::running->ss = tss;
            PCB::running->bp = tbp;

		    if(!PCB::running->finished && !PCB::running->blocked && !PCB::running->idle){
				//PCB::running->ready = 1;
		    	Scheduler::put(PCB::running);
		    }

		    PCB::running = Scheduler::get();

			if(PCB::running==0) {
			       /*cout<<"IDLE DOBIO"<<endl;*/
                   if(mainPCB->ready==0)  PCB::running =(PCB*) idlePCB;
                   else PCB::running = (PCB*)mainPCB;
			        }



		    tsp = PCB::running->sp;
		    tss = PCB::running->ss;
            tbp = PCB::running->bp;

		    counter = PCB::running->timeSlice;
          //  cout<<"Novi COUNTER JE : "<<counter<<endl;
#ifndef BCC_BLOCK_IGNORE
		asm {
			mov sp, tsp   // restore sp
			mov ss, tss
			mov bp, tbp
		}
#endif



		}
		else contextOnDemand = 1;

	}

}



void restore(){


	Thread* thr = mainPCB->myThread;
	delete thr;
	mainPCB = 0;
	thr = 0;

  Thread* thr_i = idlePCB->myThread;
  delete thr_i;
  idlePCB = 0;
  thr_i = 0;



  if(PCB::running) {
	  delete PCB::running; PCB::running = 0;
  }
  if (idlePCB){
	  delete idlePCB; idlePCB = 0;
  }
  if(mainPCB){
	  delete mainPCB; mainPCB = 0;
  }
  if(pcbList){
	  delete (List*)pcbList; (List*)pcbList = 0;
  }


#ifndef BCC_BLOCK_IGNORE
	asm {
		cli
		push es
		push ax

		mov ax,0
		mov es,ax


		mov ax, word ptr oldTimerSEG
		mov word ptr es:0022h, ax
		mov ax, word ptr oldTimerOFF
		mov word ptr es:0020h, ax

		pop ax
		pop es
		sti
	}
#endif
}




