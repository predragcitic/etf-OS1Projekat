

#include "WList.h"

WList::WList() {

	head = curr = temp = tail = 0;
}

WList::~WList() {
	curr = head;
	if (!curr){
		temp = tail = 0;
	}
	else while(curr){
		temp = curr;
		curr = curr->next;
		delete temp;
	}
	// SVE NA NULA POSTAVI
}
void WList::addNode(PCB* newPCB, Time max){
	node* n = new node;

	n->data = newPCB;
    n->timeslice = max;
	n->next = 0;

	if(head) {
		tail->next = n;
		tail = n;
	}
	else {
		head = tail = n;
	}
}

PCB* WList::takeFirst(){
if (head==0) return 0;
else{
	temp = head;
	head = head->next;
	if (head==0) tail = 0;
	return temp->data;
	delete temp; // PAZI NA OVO !!!!
}
}


void WList::deleteNode(PCB* delPCB){
    temp = 0;
	curr = head;
	while(curr && curr->data!=delPCB){
		temp = curr;
		curr = curr->next;
	}
	if (!curr) return;

	if(curr == head) {head = head->next; delete curr;  if (head ==0) tail = 0;}
	else if(curr == tail) {tail = temp; delete curr; tail->next = 0;}
	else {temp -> next = curr -> next; delete curr;}
}
