

#include "SemList.h"

SemList::SemList() {
head = curr = temp = tail = 0;

}

SemList::~SemList() {
	curr = head;
	if (!curr){
		temp = tail = 0;
	}
	else while(curr){
		temp = curr;
		curr = curr->next;
		delete temp;
	}
}

void SemList::addNode(KernelSem* newKer){
	node* n = new node;
		n->next = 0;
		n->data = newKer;

		if(head) {
			tail->next = n;
			tail = n;
		}
		else {
			head = tail = n;
		}
}
void SemList::deleteNode(KernelSem* delKer){

	    temp = 0;
		curr = head;
		while(curr && curr->data!=delKer){
			temp = curr;
			curr = curr->next;
		}
		if (!curr) return;

		if(curr == head) {
			 if (head ==0) tail = 0;
			 else {head = head->next; delete curr;}
		}
		else if(curr == tail) {tail = temp; delete curr; tail->next = 0;}
		else {temp -> next = curr -> next; delete curr;}

}
