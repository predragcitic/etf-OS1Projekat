

#include "PCB.h"
//#include <dos.h>
#include "List.h"
#include <stdio.h>


PCB* PCB::running = 0;

PCB::PCB(StackSize sz , Time time , Thread* thr) {
	// TODO Auto-generated constructor stub

	id = ++posID;
	size = sz/sizeof(unsigned);
	stack = new unsigned[size];

	myThread = thr;
	timeSlice = time;
	if (timeSlice == 0)  timeSliceZero = 1;
	else timeSliceZero = 0;

	stack[size-1] = 0x200;
#ifndef BCC_BLOCK_IGNORE
	stack[size-2] = FP_SEG(PCB::wrapper);
	stack[size-3] = FP_OFF(PCB::wrapper);
	ss = FP_SEG(stack+size-12);
	sp = FP_OFF(stack+size-12);
#endif
	bp = sp;


finished = 0;
blocked = 0;
started = 0;
ready = 0;
idle = 0;
wasWaiting = 0;

//extern volatile List* pcbList;
 ((List*)pcbList)->addNode(this);   //dodajem u listu svih PCB-ova, odnosno threadova
 pcbWaiting = new List();

}

PCB::~PCB() {
	lockFlag = 0;
	delete []stack;
	stack = 0;
	delete pcbWaiting;
	pcbWaiting = 0;
	lockFlag = 1;

}

 void PCB::wrapper(){

	    //extern volatile PCB* running;

       if(PCB::running && PCB::running->myThread)
	   PCB:: running->myThread->run();

       lockFlag = 0;
       PCB::running-> finished = 1;
	   PCB:: running->pcbWaiting->wakeUp();
	   lockFlag = 1;

		dispatch();
}
