

#include "KernelSe.h"
#include "SemList.h"
#include "SCHEDULE.H"



KernelSem::KernelSem(int init) {
   if(value<0) value = 0;
   else	value = init;
   blockedThreads = new WList();
   numOfBlockedThreads = 0;
   ((SemList*)allSemaphores)->addNode(this);
}

KernelSem::~KernelSem() {
  ((SemList*)allSemaphores)->deleteNode(this);
  delete blockedThreads;
  numOfBlockedThreads = 0;
  value = 0;
}


int KernelSem::wait (Time maxTimeToWait){

	//lockFlag = 0;
	int ret;

    if (maxTimeToWait<0) ret = 1;

	if (maxTimeToWait>=0){
	         value--;
	         if(value<0 && !PCB::running->idle){
	        		PCB::running->blocked = 1;
	        		PCB::running->ready = 0;
	        		blockedThreads->addNode(PCB::running, maxTimeToWait);
	        		numOfBlockedThreads++;

	        		dispatch();

                    if(PCB::running->wasWaiting) ret = 0;
	        	    else ret = 1;
	         }else ret = 1;

	}

	//lockFlag =1;
    return ret;
}


int KernelSem::signal(int n){
//lockFlag = 0;
	int ret;
    if(n<0)  ret = n;

    if(n==0){
	       if(value++<0){
	          if(numOfBlockedThreads>0){
	        	numOfBlockedThreads--;
	        	PCB* taken = blockedThreads->takeFirst();
	        	taken->blocked = 0;
	        	taken->ready = 1;
	        	Scheduler::put(taken);
	          }
	       ret = 0;    // vidi treba li return sta da se promeni i za wait i za signal
	       }
    }

    value+=n;
    ret = deblock(n);

return ret;
//lockFlag = 1;

}


int KernelSem::val () const{
return value;
}




int KernelSem::deblock(int n){
	int ret;
	if(!numOfBlockedThreads) return 0;

	if (n>numOfBlockedThreads){
		ret = numOfBlockedThreads;

		while(numOfBlockedThreads>0){
		    PCB* take = blockedThreads->takeFirst();
		    numOfBlockedThreads--;
		    take->blocked = 0;
		    take->ready = 1;
		    Scheduler::put(take);
		}

	}
	else {
		ret = n;
		int i = n;
		while(i>0){
			PCB* take = blockedThreads->takeFirst();
			numOfBlockedThreads--;
			i--;
			take->blocked = 0;
			take->ready = 1;
			Scheduler::put(take);
		}
	}



	return ret;
}


void check(){

	allSemaphores->curr = allSemaphores->head;

	if(!allSemaphores->curr) return;

    while(allSemaphores->curr){
    	allSemaphores->curr->data->blockedThreads->curr = allSemaphores->curr->data->blockedThreads->head;
    	if(!allSemaphores->curr->data->blockedThreads->curr) {allSemaphores->curr = allSemaphores->curr->next; continue;}
    	else while(allSemaphores->curr->data->blockedThreads->curr){
    		if(allSemaphores->curr->data->blockedThreads->curr->timeslice>0){
    			allSemaphores->curr->data->blockedThreads->curr->timeslice--;
                if(allSemaphores->curr->data->blockedThreads->curr->timeslice == 0){
                	allSemaphores->curr->data->blockedThreads->curr->data->blocked = 0;
                	allSemaphores->curr->data->blockedThreads->curr->data->ready = 1;
                	Scheduler::put(allSemaphores->curr->data->blockedThreads->curr->data);
                    allSemaphores->curr->data->value++;
                    allSemaphores->curr->data->numOfBlockedThreads--;
                    allSemaphores->curr->data->blockedThreads->curr->data->wasWaiting = 1;
                	allSemaphores->curr->data->blockedThreads->deleteNode(allSemaphores->curr->data->blockedThreads->curr->data);
                }
    		}
    		allSemaphores->curr->data->blockedThreads->curr = allSemaphores->curr->data->blockedThreads->curr->next;
    	}
    	allSemaphores->curr = allSemaphores->curr->next;
    }
    return;

}

