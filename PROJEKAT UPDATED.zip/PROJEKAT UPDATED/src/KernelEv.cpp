

#include "KernelEv.h"
#include "IVTEntry.h"
#include "PCB.h"

KernelEv::KernelEv(IVTNo ivtnum) {
	value = 0;
	myOwner = PCB::running;
	ivtNum = ivtnum;
	IVTEntry * newEntry = IVTEntry::entries[ivtNum];
	if (newEntry && newEntry->myEvent == 0)
		newEntry->myEvent = this;
}

KernelEv::~KernelEv() {
	signal();
	if (IVTEntry::entries[ivtNum] && IVTEntry::entries[ivtNum]->myEvent == this)
		IVTEntry::entries[ivtNum]->myEvent = 0;
}
void KernelEv::wait() {
	if (myOwner != PCB::running) {
		value = 0;

	}
	else {
		if(value==0) {
		value = 0;
		myOwner->ready = 0;
		myOwner->blocked=1;
		dispatch();
	}
	}

}
void KernelEv::signal() {
	if (value==0) {
		value = 1;
		myOwner->ready = 1;
		myOwner->blocked=0;
		Scheduler::put(myOwner);
		dispatch();
	}
}
