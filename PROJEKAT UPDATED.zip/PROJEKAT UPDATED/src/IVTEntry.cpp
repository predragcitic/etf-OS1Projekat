


#include "IVTEntry.h"
#include "KernelEv.h"
#include <dos.h>

IVTEntry *IVTEntry::entries[256] ={0};

IVTEntry::IVTEntry(IVTNo ivtnum,pInterrupt prekid) {
    lock;
	ivtNumber=ivtnum;
    myEvent=0;
#ifndef BCC_BLOCK_IGNORE
	oldInt=getvect(ivtNumber);
	setvect(ivtNumber,prekid);
#endif
    entries[ivtNumber]=this;
    unlock;
}

IVTEntry::~IVTEntry() {
lock;
#ifndef BCC_BLOCK_IGNORE
	setvect(ivtNumber,oldInt);
#endif
	entries[ivtNumber]=0;
    callOld();
unlock;
}


void IVTEntry::signal(){
lock;
	if (myEvent){
			myEvent->signal();
		}
unlock;
}

void IVTEntry::callOld() {

	if(oldInt) (*oldInt)();
}
