

#include "Thread.h"
#include "PCB.h"
#include "Schedule.h"
#include "List.h"
#include <dos.h>
//#include "Global.h"





Thread::Thread(StackSize stackSize, Time timeSlice ) {
   if (stackSize>maxStackSize){
	   stackSize = maxStackSize;

   }
   lockFlag = 0;
   myPCB = new PCB(stackSize, timeSlice, this);
   lockFlag = 1;
}
void Thread::start(){
lockFlag = 0;
if (!myPCB->started){

	myPCB->started = 1;
	myPCB->ready = 1;
	Scheduler::put(myPCB);
lockFlag = 1;
}
}

ID Thread::getId(){
  return myPCB->id;
}

ID Thread::getRunningId(){

	return  PCB::running->id;
}
Thread* Thread::getThreadById(ID id){

	return ((List*)pcbList)->findThreadByID(id);
}
Thread::~Thread() {
if(!myPCB->idle) waitToComplete();

((List*)pcbList)->deleteNode(myPCB);
lockFlag = 0;
if(myPCB) delete myPCB;
lockFlag = 1;
myPCB = 0;

}

void Thread::waitToComplete(){

if(!myPCB->finished && !PCB::running->finished){
	        lockFlag = 0;
		    ((List*)(myPCB->pcbWaiting))->addNode(PCB::running);
			PCB::running ->blocked = 1;
			PCB::running->ready = 0;
			lockFlag = 1;
			dispatch();
}


}


void dispatch(){

    lock;
	contextOnDemand = 1;
	timer();
	unlock;

}
