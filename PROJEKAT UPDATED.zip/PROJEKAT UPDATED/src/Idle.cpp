
#include "Idle.h"
//#include "Global.h"
//#include "Thread.h"
#include "PCB.h"


extern volatile PCB* idlePCB;


Idle::Idle():Thread(defaultStackSize,1){
  myPCB->idle = 1 ;
  idlePCB = myPCB;
  start();
}


void Idle::run(){
	while(1){};
}

